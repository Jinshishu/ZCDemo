//
//  PortraitSegmentationViewController.h
//  MNNKitDemo
//
//  Created by tsia on 2019/12/26.
//  Copyright © 2019 tsia. All rights reserved.
//

#import "VideoBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PortraitSegmentationViewController : VideoBaseViewController

@end

NS_ASSUME_NONNULL_END
