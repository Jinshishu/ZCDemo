//
//  HandGestureDetectionImageViewController.h
//  MNNKitDemo
//
//  Created by tsia on 2020/1/13.
//  Copyright © 2020 tsia. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HandGestureDetectionImageViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
