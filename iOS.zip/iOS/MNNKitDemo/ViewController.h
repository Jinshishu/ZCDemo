//
//  ViewController.h
//  MNNKitDemo
//
//  Created by tsia on 2019/12/24.
//  Copyright © 2019 tsia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

